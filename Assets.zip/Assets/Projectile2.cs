using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Projectile2 : MonoBehaviour
{
    private Rigidbody2D rb;
    private SpringJoint2D springJoint;
    private bool isPress;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        springJoint = GetComponent<SpringJoint2D>();
    }

    // Update is called once per frame
    void Update()
    {
        if(isPress){
            rb.position = Camera.main.ScreenToWorldPoint (Input.mousePosition);
        }
        
    }

    private void OnMouseDown(){
        isPress = true;
        rb.isKinematic = true;

    }

    private void OnMouseUp(){
        isPress = false;
        rb.isKinematic = false;
        StartCoroutine(Release());
    }

    IEnumerator Release(){
        yield return new WaitForSeconds(0.15f);
        GetComponent<SpringJoint2D>().enabled = false;

        yield return new WaitForSeconds(8f);

        if(Die2.enemyAlive > 0){
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

    }       
    }

}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Die : MonoBehaviour
{
    public GameObject Bird;
    public GameObject Pattern;
    public static int enemyAlive = 0;
    public float health = 3f;

    private void Start()
    {
        enemyAlive++;
    }
    
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.relativeVelocity.magnitude>health) {
            Destroy();
        }
    }

    private void Destroy()
    {
        
        Destroy(Bird);
        Instantiate(Pattern, transform.position, Quaternion.identity);

        enemyAlive--;
        if (enemyAlive <= 0) {
          
            Debug.Log("WON");
            SceneManager.LoadScene("Level2");
        }

        
    }

}

// using System.Collections;
// using System.Collections.Generic;
// using UnityEngine;
// using UnityEngine.SceneManagement;

// public class Die : MonoBehaviour {

//     public float health = 3f;
//     public GameObject Pattern;
//     public static int enemyAlive = 0;

//     private void Start()
//     {
//         enemyAlive++;
//     }

//     private void OnCollisionEnter2D(Collision2D collision)
//     {
//         if (collision.relativeVelocity.magnitude>health) {
//             Destroy1();
//         }
//     }

//     private void Destroy1() {
//         Instantiate(Pattern, transform.position, Quaternion.identity);
//         enemyAlive--;
//         if (enemyAlive <= 0) {
          
//             Debug.Log("WON");
//             SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
//         }
    
//         Destroy(gameObject);
//     }
// }

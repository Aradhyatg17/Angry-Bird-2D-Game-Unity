using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
// using UnityEngine.UI;

public class Die2 : MonoBehaviour
{
    public GameObject Bird;
    public GameObject Pattern;
    public static int enemyAlive = 0;
    public float health = 3f;
    
    private void Start()
    {
        enemyAlive++;
    }
    
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.relativeVelocity.magnitude>health) {
            Destroy();
        }
    }

    private void Destroy()
    {
        
        Destroy(Bird);
        Instantiate(Pattern, transform.position, Quaternion.identity);

        enemyAlive--;
        if (enemyAlive <= 0) {
          
            Debug.Log("WON");

            SceneManager.LoadScene("Level4");
        }

        
    }

}